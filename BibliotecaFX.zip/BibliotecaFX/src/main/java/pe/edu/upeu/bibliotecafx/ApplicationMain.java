package pe.edu.upeu.bibliotecafx;

public class ApplicationMain {
    public static void main(String[] args) {
        BibliotecaFxApplication.main(args);
    }
}
