package pe.edu.upeu.bibliotecafx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaFxApplicationTests {

	@Test
	void contextLoads() {
	}

}
